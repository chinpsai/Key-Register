// KEY REGISTER - Apps Script API (used by the GitHub Pages app)
// Users (name, PIN, role) are kept in the "Users" sheet of this spreadsheet.

const KEYS = [
['HBPTC',['SR BP N1','SR BP N2','SR BPN4','SR BP N5','SR BPN6','SR BT','SR UP']],
['MYTTC',['SR01WL','SR02WL','SR03WL','SR04WL','SR05WL','SR08WL','SR09WL (BTO)','5/600+SR / YT SR','700+SR / CCK SR']],
['SBTC',['SR01GB','SR03SB','SR04SB','SR05SB','SR06SB','SR05WL','SR06WL','SR07WL','SR08WL']],
['NSTC',['SR01YN','SR02YN','SR03YN','SR05YN','SR06YN','SR07YN','SR08YN','SR09YN','SR04YN']],
['WCTC',['SRW 25 (West Coast)','SR22 (Telok Blangah)','SRP13 (Pioneer)','SRB33 (Boon Lay)','SRA12 (Pandan/Teban Garden)','TMR','SKD0010 NY-SR100VW','CCK7 HKN SR 305 CJ / HN SR (new key 08 Mar 21)','+1 small key']],
['CCKTC',['SKD0006 CCK-SR11VW / CCK SR','SKD0022 KH-SR259VW / KH SR','CCK2 HKN SRC12CJ / HN SR (HKN new BTO)','HKNSR 159-CJ / HKN SR','CCK23-BG SR 120CJ / BG SR']],
['JBTC',['MR3 (Kampong Glam)','SR-PP (Potong Pasir)','SR KK (Kreta Ayer)','SR (Kolam Ayer & Whampoa)']],
['PRPTC & SKTC',['Pasir Ris Div','Punggol / Compassvale (w/ yellow "M" tag)','RV (Duplicate) PESR 1,2,3,4,5,6']],
['AMKTC',['SR01KB','SR02K8']]
];

function doGet() { return json_({ ok: true, msg: 'Key Register API is running' }); }

function doPost(e) {
  try {
    setup_();
    const q = JSON.parse(e.postData.contents);
    const name = String(q.name || '').trim();
    const lockKey = 'fail_' + name.toLowerCase();
    const cache = CacheService.getScriptCache();
    if (Number(cache.get(lockKey) || 0) >= 5) return json_({ error: 'Too many wrong attempts. Try again in 10 minutes.', auth: false });
    const user = findUser_(name, q.pin);
    if (!user) {
      cache.put(lockKey, String(Number(cache.get(lockKey) || 0) + 1), 600);
      return json_({ error: 'Wrong name or PIN.', auth: false });
    }
    cache.remove(lockKey);
    if (q.a == 'borrow') return json_(borrow_(user, q));
    if (q.a == 'return') return json_(returnKey_(user, q));
    if (q.a == 'delete') return json_(deleteRecord_(user, q));
    return json_({ state: state_(user) });
  } catch (err) {
    return json_({ error: 'Server error: ' + err.message });
  }
}

function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }
function d_(v) { return v instanceof Date ? Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd') : String(v || ''); }
function pin_(v) { v = String(v == null ? '' : v).trim(); return /^\d+$/.test(v) ? ('0000' + v).slice(-Math.max(4, v.length)) : v; }

// Run this once from the editor (Run > setup) to create the sheets and authorise.
function setup() { setup_(); }

function setup_() {
  const ss = ss_();
  let k = ss.getSheetByName('Keys');
  if (!k) {
    k = ss.insertSheet('Keys');
    const rows = [['Town Council', 'Key']];
    KEYS.forEach(g => g[1].forEach(x => rows.push([g[0], x])));
    k.getRange(1, 1, rows.length, 2).setValues(rows);
    k.getRange(1, 1, 1, 2).setFontWeight('bold'); k.setFrozenRows(1);
  }
  let l = ss.getSheetByName('Log');
  if (!l) {
    l = ss.insertSheet('Log');
    l.getRange(1, 1, 1, 9).setValues([['ID', 'Town Council', 'Key', 'Borrower', 'Borrowing date', 'Return date', 'Issued by', 'Received by', 'Recorded at']]).setFontWeight('bold');
    l.getRange('E:F').setNumberFormat('@'); l.setFrozenRows(1);
  }
  let u = ss.getSheetByName('Users');
  if (!u) {
    u = ss.insertSheet('Users');
    u.getRange('B:B').setNumberFormat('@');
    u.getRange(1, 1, 3, 3).setValues([['Name', 'PIN', 'Role (Admin or Borrower)'], ['Admin', '1234', 'Admin'], ['Staff 1', '1111', 'Borrower']]);
    u.getRange(1, 1, 1, 3).setFontWeight('bold'); u.setFrozenRows(1); u.setColumnWidth(3, 190);
  }
}

function findUser_(name, pin) {
  const rows = ss_().getSheetByName('Users').getDataRange().getValues().slice(1);
  const n = String(name || '').trim().toLowerCase(), p = pin_(pin);
  if (!n || !p) return null;
  for (const r of rows) {
    if (String(r[0]).trim().toLowerCase() == n && pin_(r[1]) == p)
      return { name: String(r[0]).trim(), admin: String(r[2]).trim().toLowerCase() == 'admin' };
  }
  return null;
}

function state_(user) {
  const ss = ss_();
  const keys = ss.getSheetByName('Keys').getDataRange().getValues().slice(1)
    .filter(r => r[0] && r[1]).map(r => ({ tc: String(r[0]), key: String(r[1]) }));
  const log = ss.getSheetByName('Log').getDataRange().getValues().slice(1)
    .filter(r => r[0]).map(r => ({ id: r[0], tc: String(r[1]), key: String(r[2]), name: String(r[3]), out: d_(r[4]), inn: d_(r[5]), by: String(r[6]), rby: String(r[7]), at: d_(r[8]) }));
  return { keys: keys, log: log, me: user.name, admin: user.admin };
}

function withLock_(fn) {
  const lock = LockService.getScriptLock(); lock.waitLock(15000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function borrow_(user, q) {
  const name = String(q.name || '').trim();
  if (!name || !q.date) return { error: 'Enter borrower name and date.' };
  return withLock_(() => {
    const sh = ss_().getSheetByName('Log');
    const rows = sh.getDataRange().getValues().slice(1);
    if (rows.some(r => r[1] == q.tc && r[2] == q.key && !d_(r[5]))) return { error: 'This key was just borrowed by someone else.', state: state_(user) };
    sh.getRange(sh.getLastRow() + 1, 1, 1, 9).setValues([[Utilities.getUuid(), q.tc, q.key, name, q.date, '', user.name, '', new Date().toISOString()]]);
    return { state: state_(user) };
  });
}

function returnKey_(user, q) {
  if (!q.date) return { error: 'Pick a return date.' };
  return withLock_(() => {
    const sh = ss_().getSheetByName('Log');
    const ids = sh.getRange(1, 1, sh.getLastRow(), 1).getValues();
    for (let i = 1; i < ids.length; i++) if (ids[i][0] == q.id) {
      sh.getRange(i + 1, 6).setValue(q.date); sh.getRange(i + 1, 8).setValue(user.name);
      return { state: state_(user) };
    }
    return { error: 'Record not found.', state: state_(user) };
  });
}

function deleteRecord_(user, q) {
  if (!user.admin) return { error: 'Only admins can delete records.' };
  return withLock_(() => {
    const sh = ss_().getSheetByName('Log');
    const ids = sh.getRange(1, 1, sh.getLastRow(), 1).getValues();
    for (let i = 1; i < ids.length; i++) if (ids[i][0] == q.id) { sh.deleteRow(i + 1); break; }
    return { state: state_(user) };
  });
}
